a=input()
print(a)
print(a)
print(a)