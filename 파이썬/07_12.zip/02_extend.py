a = ['apple']
a.extend('banana','mango')
print(a)
#a.extend('banana')
#print(a)