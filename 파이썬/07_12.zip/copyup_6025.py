number = input()
print(int(number) + 5)
