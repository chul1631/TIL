numbers = [7, 17, 10, 5, 4, 3, 17, 5, 2, 5]
cnt = numbers(5)
numbers = list(map(int, input(cnt).split()))
print(cnt)

list_test = [1, 1, 2, 2, 2, 3, 3, 10, 5, 5, 5, 5, 8, 8, 7, 7, 'a', 'a', 'bb', 'bb', 'bb', '\n']

cnt_5 = list_test.count(5) # 1
print(cnt_5)