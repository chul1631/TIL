a = [1, 2, 3]
a = a.append(4)
print(a)

a = [1, 2, 3]
# sum 함수의 return 값을 result에 할당
result = sum(a)
