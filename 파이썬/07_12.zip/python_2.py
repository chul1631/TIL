print('kdt!')
print('kkk')
print('123')
