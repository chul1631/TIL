def cube(n):
    return (n**3)
result = cube(12)
print(result)


    