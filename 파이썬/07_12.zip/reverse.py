word = 'apple'
reverse_name = ''

for a in word:
    word = a + reverse_name
print(f'word:{reverse_name}')