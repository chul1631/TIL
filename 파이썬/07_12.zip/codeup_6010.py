
a = input(11) 
b = input(22)
a=int(a)
b=int(b)
print(a)
print(b)
