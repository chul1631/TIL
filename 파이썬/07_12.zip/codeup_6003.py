print("Hello")
print("World")