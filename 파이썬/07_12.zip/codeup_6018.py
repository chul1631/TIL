a,b = input().split(':')
print(a,b,sep =':')
