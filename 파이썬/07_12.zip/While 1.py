# While
a=0
b=1
n=10


while b<=n:
    a += b
    b += 1
print(f'{a}')

#for
a=0
b=10

for b in range(1, n+1):
    a += b
print(f'{a}')








