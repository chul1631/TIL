numbers = [3, 10, 20]
av=0
for i in numbers:
    av += i
    print (av/3)