set_a = {1, 2, 3, 1, 1}
set_b = {'hi', 1, 2}
print(set_a) 
print(set_b)

locations = ['서울', '서울', '대구', '광주', '제주', '대구']
print(set(locations)) 
print(len(set(locations)))
