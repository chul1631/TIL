text = input()
print(text)