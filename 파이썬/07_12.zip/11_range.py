numbers = range(5)
print(numbers)
print(list(numbers))


    