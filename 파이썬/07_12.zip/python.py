print("hello world")

a=1

print(a)

