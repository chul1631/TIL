name ='손세철'

def ad (a, b, c )

    return a+b+c
print (ad)
