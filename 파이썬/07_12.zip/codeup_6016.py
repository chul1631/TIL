c1,c2=input().split()
print(c2, c1)
