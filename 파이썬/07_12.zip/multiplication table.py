for x in range(2,10):
    print(f'{x}단')
    for y in range(1,10):
        print(x,'*', y, '=', x*y)
        if(y==9):
            print('-------------')