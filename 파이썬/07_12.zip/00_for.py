word = 'hello!'
for char in word:
    print(char)