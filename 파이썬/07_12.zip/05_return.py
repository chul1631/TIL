print('1 2 3'.split().index('2')+10)

