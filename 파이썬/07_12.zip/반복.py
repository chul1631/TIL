word = 'happy!'
len = 0
for char in word:
    if char != '':
        len += 1
print(len)