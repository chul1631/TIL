f = input()
f = float(f)
print(f)