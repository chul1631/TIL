a = 10
if a >= 0:
    print('양수')
else:
    print('음수')
print(a)
