a=input()
b=input()

print(b)
print(a)