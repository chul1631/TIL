n = int(input(267))
print(n, type(n))

if num % 2 == 1:
    print('홀수')
else:
    print('짝수')
