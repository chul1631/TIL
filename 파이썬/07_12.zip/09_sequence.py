numbers = [1, 100, 20, 50]

print(numbers[1]) 
print(numbers[2:3]) 
print(len(numbers)) 
print(sum(numbers)) 
print(max(numbers)) 
print(min(numbers)) 
