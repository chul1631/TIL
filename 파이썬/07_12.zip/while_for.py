n = 10
i = 0
sum = 0
while i <= n:
    sum += n
    n += 1

print(f'{sum}')