# 정의
# 1. def
# 2. add : 함수의 이름
# 3. Input : a, b
def add(a,b): 
#4. return : 값을 반환
    return a + b
# 호출
def minus(a, b):
     return a-b
print (add(5, 10))

print(minus(10, 5))

# 내장 함수 호출
print(sum([1,2,3]))
