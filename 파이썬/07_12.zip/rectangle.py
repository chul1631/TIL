def rec(a, b):
    return a * b
print(rec(20, 30))

def rec(a, b):
    return (a + b)* 2
print(rec(20, 30))
